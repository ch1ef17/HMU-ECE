public abstract class classes {
    private double price;

    public classes(double price) {
        this.price = price;
    }

    public double getPrice() {
        return price;
    }

    public abstract double finalPrice();
}

class Laptop extends classes {
    private String brand;

    public Laptop(double price, String brand) {
        super(price);
        this.brand = brand;
    }

    @Override
    public double finalPrice() {
        return getPrice() * 0.85;
    }
}

class Smartphone extends classes {
    private String color;

    public Smartphone(double price, String color) {
        super(price);
        this.color = color;
    }

    @Override
    public double finalPrice() {
        return getPrice() * 0.9;
    }
}