public class Main {
    public static void main(String[] args) {
        Laptop laptop = new Laptop(1000, "HP");
        Smartphone smartphone = new Smartphone(500, "Black");

        System.out.println("Final price of the laptop: $" + laptop.finalPrice());
        System.out.println("Final price of the smartphone: $" + smartphone.finalPrice());
    }
}
