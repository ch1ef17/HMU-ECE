import javax.swing.*;

/**
 *
 * @author tolys
 */
public class Main {
    public static void main(String[] args) {
         SwingUtilities.invokeLater(() -> {
            MainJFrame frame = new MainJFrame();
            frame.setVisible(true);
         });
       
    }
}
