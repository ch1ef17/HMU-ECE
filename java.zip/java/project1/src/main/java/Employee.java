import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.*;
import java.nio.file.*;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;

@SuppressWarnings("unused")
public class Employee {
    private int id;
    private String name;
    private double salary;
    private double tax;
    private double insurance;

    public Employee(int id, String name) {
        this.id = id;
        this.name = name;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public String getName() {
        return name;
    }
    
    public String toString() {
    return "ID: " + id + ", Name: " + name;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }
    
    public double getSalary() {
        return salary;
    }

    public double getTax() {
        return tax;
    }

    public void setTax(double tax) {
        this.tax = tax;
    }

    public double getInsurance() {
        return insurance;
    }

    public void setInsurance(double insurance) {
        this.insurance = insurance;
    }
    //-----------------------------------------------------//
    
    public void saveToFile(Employee employee) {
    String fileName = "employees.txt";
    File file = new File(fileName);

    try {
        BufferedReader reader = new BufferedReader(new FileReader(file));
        String line;
        boolean idExists = false;
        while ((line = reader.readLine()) != null) {
            if (line.startsWith(employee.getId() + ",")) {
                idExists = true;
                break;
            }
        }
        reader.close();
        
        if (idExists) {
            deleteLineFromFile(file, employee.getId());
        }
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file, true))) {
            writer.write(employee.getId() + "," + employee.getName() + "," + employee.getSalary() + "\n");
            System.out.println("Employee information saved to " + fileName);
        } catch (IOException e) {
            System.err.println("Error writing to file: " + e.getMessage());
        }
    } catch (IOException e) {
        System.err.println("Error reading file: " + e.getMessage());
    }
}

private void deleteLineFromFile(File file, int employeeId) {
    try {
        Path filePath = Paths.get(file.getAbsolutePath());
        Charset charset = StandardCharsets.UTF_8;
        String content = new String(Files.readAllBytes(filePath), charset);
        content = content.replaceAll("(?m)^" + employeeId + ",\\S+,(\\S+)$", "");
        Files.write(filePath, content.getBytes(charset));
        System.out.println("Previous entry for employee ID " + employeeId + " deleted from file.");
    } catch (IOException e) {
        System.err.println("Error deleting line from file: " + e.getMessage());
    }
}
    
    public void deleteFromFile(int employeeId) {
        String fileName = "employees.txt";
        File inputFile = new File(fileName);
        File tempFile = new File("temp.txt");
        try (BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile))) {
            String lineToRemove = employeeId + ",";
            String currentLine;        
            while ((currentLine = reader.readLine()) != null) {
                if (currentLine.startsWith(lineToRemove)) {
                    continue;
                }
                writer.write(currentLine + System.getProperty("line.separator"));
            }
        } catch (IOException e) {
            System.out.println("Error deleting employee info: " + e.getMessage());
        }
        if (!inputFile.delete()) {
            System.out.println("Failed to delete the original file.");
            return;
        }
        if (!tempFile.renameTo(inputFile)) {
            System.out.println("Failed to rename the temporary file.");
        }
    }
    
    public double readSalaryFromFile(int employeeId) {
    String fileName = "employees.txt";
    try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
        String line;
        while ((line = reader.readLine()) != null) {
            String[] parts = line.split(",");
            if (parts.length >= 3) {
                int idFromFile;
                try {
                    idFromFile = Integer.parseInt(parts[0]);
                } catch (NumberFormatException e) {
                    continue;
                }
                if (idFromFile == employeeId) {
                    try {
                        return Double.parseDouble(parts[2]);
                    } catch (NumberFormatException e) {
                        return 0.0;
                    }
                }
            }
        }
    } catch (IOException e) {
        e.printStackTrace();
    }
    return 0.0;
}
}
