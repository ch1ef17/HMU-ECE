import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;


@SuppressWarnings("unused")
public class Payroll {
    private Employee employee;
    private List<Employee> employees;
    private double tax = 0.15;
    private double insurance = 0.10;
    private double salary;
    private MainJFrame mainFrame;

    public Payroll() {
        employees = new ArrayList<>();
    }
    
    public double getTax() {
        return tax;
    }
    
    public double getInsurance() {
        return insurance;
    }
    
    public void setTax(double newTaxRate) {
        tax = newTaxRate;
        System.out.println("Tax rate updated successfully.");
    }
    
    public void setInsurance(double newInsuranceRate) {
        insurance = newInsuranceRate;
        System.out.println("Insurance rate updated successfully.");
    }
    public double getSalary() {
        return salary;
    }
    
    public void addEmployee(Employee emp) {
        employees.add(emp);
        System.out.println("Employee added successfully.");
    }
    
    public Employee findEmployee(int employeeId) {
        String fileName = "employees.txt";
        return findEmployee(employeeId, fileName);
    }
    
    public static Employee findEmployee(int employeeId, String fileName) {
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split(",");
                if (parts.length >= 2) {
                    try {
                        int id = Integer.parseInt(parts[0].trim());
                        if (id == employeeId) {
                            String name = parts[1].trim();
                            return new Employee(id, name);
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("Invalid employee ID found: " + parts[0]);
                    }
                } else {
                    System.out.println("Invalid data format: " + line);
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error finding employee: " + e.getMessage());
        }
        return null;
    }
    
    public static List<Employee> getEmployees(String fileName) {
        List<Employee> employees = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.isEmpty()) {
                    String[] parts = line.split(",");
                    if (parts.length >= 2) {
                        try {
                            int id = Integer.parseInt(parts[0].trim());
                            String name = parts[1].trim();
                            employees.add(new Employee(id, name));
                        } catch (NumberFormatException e) {
                            System.out.println("Invalid employee ID found: " + parts[0]);
                        }
                    } else {
                        System.out.println("Invalid data format: " + line);
                    }
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Error reading employee data from file: " + e.getMessage());
        }
        return employees;
    }

    
    public void removeEmployee(Employee employee) {
        employees.remove(employee);
    }
    
    public void setSalary(int employeeId, double salaryAmount) {
        Employee employee = findEmployee(employeeId);
        if (employee != null) {
            employee.setSalary(salaryAmount);
            employee.saveToFile(employee);
            System.out.println("Salary added successfully for employee " + employeeId);
        } else {
            System.out.println("Employee with ID " + employeeId + " not found.");
        }       
    }  
}