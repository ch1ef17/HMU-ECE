
import java.awt.Dimension;
import java.io.*;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

/**
 *
 * @author tolys
 */
@SuppressWarnings("unused")
public class MainJFrame extends javax.swing.JFrame {
    
    private static final String EMPLOYEE_FILE_NAME = "employees.txt";
    
    private Payroll payroll;
    private Employee employee;

    
    public MainJFrame() {
        initComponents();
        jButton1.addActionListener(this::jButton1ActionPerformed);
        jButton2.addActionListener(this::jButton2ActionPerformed);
        jButton3.addActionListener(this::jButton3ActionPerformed);
        jButton4.addActionListener(this::jButton4ActionPerformed);
        jButton5.addActionListener(this::jButton5ActionPerformed);
        jButton6.addActionListener(this::jButton6ActionPerformed);
        jButton7.addActionListener(this::jButton7ActionPerformed);
        jButton8.addActionListener(this::jButton8ActionPerformed);
        
        jTextArea2.setText("Welcome to the Payroll Management System\nFirst add an employee ( Id , Name ).\nIn Tax and Insurance rate inputs must be ( 0. ).\nIn add salary enter ( Id , Salary ).\nIn show salary / Delete emploee enter Id.\n-------------------------------------------------------------\n");
        
        payroll= new Payroll();
        employee= new Employee(0, "");
        
        this.payroll= payroll;
       
        double tax = payroll.getTax();
    }
    
    private void initComponents() {
        
        @SuppressWarnings("static-access")
        List<Employee> employees = payroll.getEmployees("employees.txt");
        
        jPanel1 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        jTextArea1 = new javax.swing.JTextArea();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
        jButton5 = new javax.swing.JButton();
        jButton6 = new javax.swing.JButton();
        jButton7 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jTextField1 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        jTextArea2 = new javax.swing.JTextArea();
        jButton8 = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        
        jScrollPane1.setPreferredSize(new Dimension(300, jScrollPane1.getPreferredSize().height));
        jScrollPane2.setPreferredSize(new Dimension(jScrollPane2.getPreferredSize().width, 200));

        jTextArea1.setColumns(20);
        
        jTextArea1.setRows(5);
        jScrollPane1.setViewportView(jTextArea1);

        jButton1.setText("Add Employee");
        jButton2.setText("Show Employees");     
        jButton3.setText("Delete Employee");
        jButton4.setText("Update Tax Rate");
        jButton5.setText("Update Insurance Rate");
        jButton6.setText("Add Salary");
        jButton7.setText("Show Salary Report");

        jLabel1.setText("Payroll Management System");
        jLabel2.setText("Input:");
        
        jButton8.setText("Exit");
        
        jTextField1.setText("");

        jTextArea2.setColumns(20);
        jTextArea2.setRows(5);
        
        jScrollPane2.setViewportView(jTextArea2);

        

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addComponent(jLabel1)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 24, Short.MAX_VALUE)
                                                .addComponent(jButton1)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jButton2)
                                                .addGap(18, 18, 18)
                                                .addComponent(jButton3)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jButton4)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jButton5)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jButton6)
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                                .addComponent(jButton7))
                                        .addGroup(layout.createSequentialGroup()
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addComponent(jScrollPane2)
                                                        .addComponent(jLabel2)
                                                        .addComponent(jTextField1))
                                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGap(18, 18, 18)               
                                                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                                                        .addGroup(layout.createSequentialGroup()
                                                                .addGap(60, 60, 60)
                                                                .addComponent(jButton8, javax.swing.GroupLayout.PREFERRED_SIZE, 121, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                                .addGap(24, 24, 24))
        );
        layout.setVerticalGroup(
                layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(layout.createSequentialGroup()
                                .addContainerGap()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                                .addComponent(jButton1)
                                                .addComponent(jButton2)
                                                .addComponent(jButton3)
                                                .addComponent(jButton4)
                                                .addComponent(jButton5)
                                                .addComponent(jButton6)
                                                .addComponent(jButton7))
                                        .addComponent(jLabel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addGroup(layout.createSequentialGroup()
                                                .addGap(27, 27, 27)
                                                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE))
                                        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 346, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                        .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                                        .addGap(13, 13, 13) 
                                        .addComponent(jTextField1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jButton8))
                                
                
        );
                
        pack();
    }

    
    public void updateEmployeeList() {
        StringBuilder employeesList = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader("employees.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                employeesList.append(line).append("\n");
            }
            jTextArea1.setText(employeesList.toString());
        } catch (IOException e) {
            // Handle file reading error
            e.printStackTrace();
            appendTextToTextArea2("Error reading employee data from file: " + e.getMessage());
        }
    }
    
    private void appendTextToTextArea2(String text) {
        jTextArea2.append(text + "\n");
    }
    
    //case 1//
    private void jButton1ActionPerformed(ActionEvent evt) {
        String input = jTextField1.getText().trim();
        if (!input.isEmpty()) {
            String[] employeeData = input.split(",");
            if (employeeData.length >= 2) {
                int id = Integer.parseInt(employeeData[0].trim());
                String name = employeeData[1].trim();
                Employee emp = new Employee(id, name);
                payroll.addEmployee(emp);
                employee.saveToFile(emp);           
                jTextField1.setText("");
                appendTextToTextArea2("Employee added successfully.");
            } else {
                // Handle invalid input format
                appendTextToTextArea2("Invalid input format. Please enter ID and name separated by a comma.");
            }
        } else {
            // Handle empty input
            appendTextToTextArea2("Input cannot be empty. Please enter ID and name separated by a comma.");
        }
    }
    //case 2//
    private void jButton2ActionPerformed(ActionEvent evt) {
        String fileName = "employee.txt";
        try (BufferedReader reader = new BufferedReader(new FileReader("employees.txt"))) {
            StringBuilder employeesList = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                String[] employeeData = line.split(",");
                if (employeeData.length >= 2) {
                    int id = Integer.parseInt(employeeData[0].trim());
                    String name = employeeData[1].trim();
                    employeesList.append("ID: ").append(id).append(", Name: ").append(name).append("\n");
                }
            }
            jTextArea1.setText(employeesList.toString());
        } catch (IOException e) {
            e.printStackTrace();
            appendTextToTextArea2("Error reading employee data from file: " + e.getMessage());
        }
    }
    //case 3//
    private void jButton3ActionPerformed(ActionEvent evt) {
        String input = jTextField1.getText().trim();
        if (!input.isEmpty()) {
            int employeeId = Integer.parseInt(input);
            Employee employee = payroll.findEmployee(employeeId);
            if (employee != null) {
                employee.deleteFromFile(employeeId);
                payroll.removeEmployee(employee);
                updateEmployeeList();
                jTextField1.setText("");
                appendTextToTextArea2("Employee with ID " + employeeId + " deleted successfully.");
            } else {
                jTextField1.setText("");
                appendTextToTextArea2("Employee with ID " + employeeId + " not found.");
            }
        } else {
            jTextField1.setText("");
            appendTextToTextArea2("Input cannot be empty. Please enter the ID of the employee to delete.");
        }
    }
    //case 4//
    private void jButton4ActionPerformed(ActionEvent evt) {
        try {
            double newTaxRate = Double.parseDouble(jTextField1.getText().trim());
            payroll.setTax(newTaxRate);
            jTextField1.setText("");
            appendTextToTextArea2("Tax rate updated successfully to " + newTaxRate);
        } catch (NumberFormatException e) {
            jTextField1.setText("");
            appendTextToTextArea2("Invalid input. Please enter a valid tax rate.");
        }
    }
    //case 5//
    private void jButton5ActionPerformed(ActionEvent evt) {
        try {
            double newInsuranceRate = Double.parseDouble(jTextField1.getText().trim());
            payroll.setInsurance(newInsuranceRate);
            jTextField1.setText("");
            appendTextToTextArea2("Insurance rate updated successfully to " + newInsuranceRate);
        } catch (NumberFormatException e) {
            jTextField1.setText("");
            appendTextToTextArea2("Invalid input. Please enter a valid insurance rate.");
        }
    }
    
    //case 6//
    private void jButton6ActionPerformed(ActionEvent evt) {
        String input = jTextField1.getText().trim();
        if (!input.isEmpty()) {
            String[] inputData = input.split(",");
            if (inputData.length >= 2) {
                try {
                    int employeeId = Integer.parseInt(inputData[0].trim());
                    int salaryAmount = Integer.parseInt(inputData[1].trim());
                    payroll.setSalary(employeeId, salaryAmount);
                    jTextField1.setText("");
                    appendTextToTextArea2("Salary added successfully for employee " + employeeId+ "," + salaryAmount);
                } catch (NumberFormatException e) {
                    jTextField1.setText("");
                    appendTextToTextArea2("Invalid input format. Please enter valid numeric values.");
                }
            } else {
                jTextField1.setText("");
                appendTextToTextArea2("Invalid input format. Please enter employee ID and salary amount separated by comma.");
            }
        } else {
            jTextField1.setText("");
            appendTextToTextArea2("Input cannot be empty. Please enter employee ID and salary amount separated by comma.");
        }
    }
  
    //case 7//
    private void jButton7ActionPerformed(ActionEvent evt) {
        int employeeId = Integer.parseInt(jTextField1.getText().trim());
        double salary = employee.readSalaryFromFile(employeeId);
        System.out.println("Salary read from file: " + salary);
        double taxAmount = salary * payroll.getTax();
        double insuranceAmount = salary * payroll.getInsurance();    
        double netSalary = salary - taxAmount - insuranceAmount;
            String report = "-----------Salary-Report----------\n" +
                        "Employee ID: " + employeeId + "\n" +
                        "Name: \n" +
                        "Salary: " + salary + "\n" +
                        "Tax: " + (payroll.getTax() * 100) + "%\n" +
                        "Insurance: " + (payroll.getInsurance() * 100) + "%\n" +
                        "Net Salary: " + netSalary + "\n" +
                        "---------------------------------------";
        jTextField1.setText("");
        appendTextToTextArea2(report);
    }

    //case 8//
    private void jButton8ActionPerformed(ActionEvent evt){
        System.exit(0);
    }
    
    public static void main(String args[]) {
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new MainJFrame().setVisible(true);
            }
        });
    }


    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JButton jButton4;
    private javax.swing.JButton jButton5;
    private javax.swing.JButton jButton6;
    private javax.swing.JButton jButton7;
    private javax.swing.JButton jButton8;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextArea jTextArea1;
    private javax.swing.JTextArea jTextArea2;
    private javax.swing.JTextField jTextField1;

}