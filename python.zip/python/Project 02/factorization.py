from collections import Counter 
import os

def factorization(i):
    paragontas={}
    diairetis=2

    while i>1:
        if i %diairetis ==0:
            count =0
            while i %diairetis ==0:
                count +=1
                i //=diairetis
            paragontas[diairetis] =count
        diairetis +=1
    return paragontas
    
def  Elaxisto_Koino_Pollaplasio(a,b):
    par_a = Counter(factorization(a))
    par_b = Counter(factorization(b))
    ekp_par = par_a | par_b
    ekp = 1
    for factor, count in ekp_par.items():
        ekp *= factor ** count
    return ekp

def Megistos_Koinos_Dieretis(a,b):
    par_a = Counter(factorization(a))
    par_b = Counter(factorization(b))
    koinoi_par = par_a & par_b
    mkd = 1
    for factor, count in koinoi_par.items():
        mkd *= factor ** count
    return mkd

a = int(input("Δώσε δυο θετικούς ακέραιους: "))
b = int(input())    

ekp = Elaxisto_Koino_Pollaplasio(a,b)
mkd = Megistos_Koinos_Dieretis(a,b)

par_a = factorization(a)
par_b = factorization(b)

print("{a} = {par_a}")
print("{b} = {par_b}")
print("EKP{a},{b}= {ekp}")
print("MKD{a},{b}= {mkd}")

os.system('pause')




