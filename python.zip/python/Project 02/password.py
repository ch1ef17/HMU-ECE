import re

def is_valid_password(pwd):
    rules=[
        any(char.isupper() for char in pwd),
        any(char.islower() for char in pwd),
        any(char.isdigit() for char in pwd),
        any(char in '!@#$&_' for char in pwd)
    ]
    if len(pwd) >=8:
        if sum(rules) >=3:
            other = any(char not in 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$&_' for char in pwd)
            if other:
                print("Το συνθηματικό σου περιέχει μη επιτρεπτούς χαρακτήρες")
            else:
                if len(pwd) !=8:
                    a=0
                else:
                    a=1
                    extra = len(pwd) -8
                    if extra >0:
                        a += extra //4
                    print("Το συνθηματικό σου είναι έγκυρο και έχει ισχύ ", a)
        else:
            print("Το συνθηματικό σου δεν περιέχει στοιχεία από τρεις τουλάχιστον κατηγορίες")
    elif len(pwd)<8:
        print("Το συνθηματικό σου πρέπει να έχει μήκος τουλάχιστον 8 χαρακτήρες")

pwd= input("Όρισε το συνθηματικό σου: ")
is_valid_password(pwd)