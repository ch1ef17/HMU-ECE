import os

print("Οι ακέραιοι από το 200 – 800 που όλα τους τα ψηφία είναι άρτιοι, είναι:")

c = range(200, 801)

for a in c:
    if(a%2)==0:
       print(a)
       
os.system("pause")




