import os 
import math

a = int(input("Dwse ena ari8mo apo to 100 ews to 300: "))

b=0

b=(a*1)+(a*2)+(a*3)+(a*4)+(a*5)+(a*6)+(a*6)+(a*7)+(a*8)+(a*9)

print("To a9roisma twn tripsifion pollaplasiwn toy {} einai {}" .format(a,b) )
os.system("pause")