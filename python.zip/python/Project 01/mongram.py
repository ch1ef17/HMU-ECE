import os

def monogram(leksi):
    leksi = leksi.lower()
    used = set()
    
    for gramma in leksi:
        if gramma in used:
            return False
        used.add(gramma)
    
    return True

def mon_grammata(leksi):
    leksi = leksi.lower()
    mon_grammata = set()

    for gramma in leksi:
        if gramma.isalpha():
            mon_grammata.add(gramma)

    return len(mon_grammata)

leksi = input("Δώσε μου μια λέξη: ")
result = monogram(leksi)

if result:
    print(f"Η λέξη '{leksi}' είναι μονογραμματική")
else:
    print(f"Η λέξη '{leksi}' δεν είναι μονογραμματική")

mon_ari8mos = mon_grammata(leksi)
print(f"Αριθμός μοναδικών χαρακτήρων: {mon_ari8mos}")


os.system("pause")