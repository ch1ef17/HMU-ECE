import os

a = input("Δώσε μια συμβολοσειρά: ")

b = 2
c = 0

c = len(a) // b

if len(a) % 2 != 0:
    middle_index = len(a) // 2
    f = a[:middle_index]
    middle = a[middle_index]
    g = a[middle_index + 1:]
else:
    f = a[:c]
    g = a[c:]

f = f[::-1]
g = g[::-1]

l = f + middle + g if len(a) % 2 != 0 else f + g

print(l)


os.system("pause")