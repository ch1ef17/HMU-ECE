import os
import re

start_file= 'test.txt'

with open(start_file, 'r', encoding='utf-8') as file:
    text= file.read()
       
words= ""
numbers= ""

for char in text:
    
    if char.isdigit():
        numbers+= char
    else:
        words+= char
        
with open('keimeno.txt', 'w', encoding='utf-8') as file:
    file.write(words)

with open('numbers.txt', 'w', encoding='utf-8') as file:
    for number in re.findall(r'\d+', numbers):
        file.write(number + '\n')
        
os.system('pause')