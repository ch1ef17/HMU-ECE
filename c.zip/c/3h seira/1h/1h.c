#include <stdio.h>
#include <stdlib.h>
#define N 10

void pinakas_auksousa(int G[], int b){
    
    int c, d, e;
    for(c=0; c<b-1; c++){
        for(d=0; d<b-c-1; d++){
            if(G[d]>G[d+1]){
                e=G[d];
                G[d]=G[d+1];
                G[d+1]=e;
            }
        }
    }
}

void pinakas_f8inousa(int H[], int f){
    int k, l, m;
    for(k=0; k<f-1; k++){
        for(l=0; l<f-k-1; l++){
            if(H[l]<H[l+1]){
                m=H[l];
                H[l]=H[l+1];
                H[l+1]=m;
            }
        }
    }
}

int main(){
    int A[N];
    int i;

    printf("Dwse 10 akeraious: ");
    for(i=0; i<N; ++i){
        scanf("%d", &A[i]);
    }

    pinakas_auksousa(A, N);

    printf("Pinakas se auksousa seira: ");
    for(i=0; i<N; ++i){
        printf("%d ", A[i]);
    }
    printf("\n");

    pinakas_f8inousa(A, N);

    printf("Pinakas se f8inousa seira: ");
    for(i=0; i<N; ++i){
        printf("%d ", A[i]);
    }
    printf("\n");

    
system("pause");
}
