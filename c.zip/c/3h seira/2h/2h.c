#include <stdio.h>
#include <stdlib.h>
#define N 5

int main(){

    char A[N][N];

    for(int i=0; i<N; i++){
        for(int a=0; a<N; a++){
            A[i][a]=' ';
        }
    }

    for(int i=0; i<N; i++){
        for(int a=0; a<=i; a++){
            A[i][a]='*';
        }
    }

    for(int i=0; i<N; i++){
        for(int a=0; a<N; a++){
            printf("%c ",A[i][a]);
        }
        printf("\n");
    }

////////////////////////////////////////////////////////////////

    for(int i=0; i<N; i++){
        for(int a=0; a<N; a++){
            A[i][a]=' ';
        }
    }
    
    for(int i=0; i<N; i++){
        for(int a=0; a<N-1; a++){
            A[i][a]='*';
        }
    }

    for(int i=0; i<N; i++){
        for(int a=0; a<N; a++){
            printf("%c ",A[i][a]);
        }
        printf("\n");
    }

system("pause");
}