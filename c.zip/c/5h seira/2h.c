#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define N 100

struct Person {
    char name[50];
    char surname[50];
    char id[50];
    char taxnumber[50];
};

void addList(struct Person* person, struct Person personArray[], int* arraySize){
    if (*arraySize < N) {
        strcpy(personArray[*arraySize].name, person->name);
        strcpy(personArray[*arraySize].surname, person->surname);
        strcpy(personArray[*arraySize].id, person->id);
        strcpy(personArray[*arraySize].taxnumber, person->taxnumber);
        (*arraySize)++;
    }
}

void printArray(struct Person personArray[], int arraySize){
    printf("Persons in the array:\n");
    for (int i = 0; i < arraySize; i++) {
        printf("Name: %s, Surname: %s, ID: %s, Tax Number: %s\n",
               personArray[i].name, personArray[i].surname,
               personArray[i].id, personArray[i].taxnumber);
    }
}

int main(){
    struct Person newPerson;
    struct Person personArray[N];
    int arraySize = 0;

    char input[10];

    while (1) {
        printf("Enter 'add' to add a person, 'end' to print the array: ");
        scanf("%s", input);

        if(strcmp(input, "add") == 0){
            printf("Enter name: ");
            scanf("%s", newPerson.name);
            printf("Enter surname: ");
            scanf("%s", newPerson.surname);
            printf("Enter ID: ");
            scanf("%s", newPerson.id);
            printf("Enter tax number: ");
            scanf("%s", newPerson.taxnumber);
            addList(&newPerson, personArray, &arraySize);
        }else if(strcmp(input, "end") == 0){
            printArray(personArray, arraySize);
            break;
        }else{
            printf("Invalid input. Try again.\n");
        }
    }

system("pause");
}