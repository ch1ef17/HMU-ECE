#include <stdio.h>
#include <stdlib.h>

int largest(int A[], int N) {
    int x;
    int max = A[0];

    for (x = 1; x < N; x++) {
        if (A[x] > max) {
            max = A[x];
        }
    }
    return max;
}

int main() {
    int N;
    printf("Enter N: ");
    scanf("%d", &N);

    int* A = (int*)malloc(N * sizeof(int));
    if (A == NULL) {
        printf("Memory allocation failed\n");
        return 1;
    }

    int i;

    for (i = 0; i < N; i++) {
        printf("Enter Number: ");
        scanf("%d", &A[i]);
    }

    printf("Plithos: %d\n", N);

    int sum = 0;
    for (i = 0; i < N; i++) {
        sum += A[i];
    }
    printf("Athroisma: %d\n", sum);

    float mo = 0;
    mo = (float)sum / N;
    printf("M.O.: %f\n", mo);

    printf("Max: %d\n", largest(A, N));

    free(A);

    system("pause");
}