#include <stdio.h>
#include <stdlib.h>

int main(){

    int i,j,k;
    printf("Dwse 3 akeraioys: ");
    scanf("%d", &i);
    scanf("%d", &j);
    scanf("%d", &k);
    
    int sum,product;
    
    sum=i+j+k;
    printf("To a8risma einai %d\n", sum);

    if(sum % 2 ==0){
        printf("To a8risma einai artios ari8mos.\n");
    }
    else{
        printf("To a8risma einai perittos ari8mos.\n");
    }
    
    product=i*j*k;
    printf("To ginomeno einai %d\n", product);

    if(product % 2 ==0){
        printf("To ginomeno einai artios ari8mos.\n");
    }
    else{
        printf("To ginomeno einai perittos ari8mos.\n");
    }

system("pause");
}