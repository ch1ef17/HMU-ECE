#include <stdio.h>
#include <stdlib.h>

int main(){

    int sel;
    float a,b,c;

    printf("1. Add\n2. Subtract\n3. Multiply\n4. Divide\n5. End\nSelect: ");
    scanf("%d",&sel);

    if(sel==5){
        return 0;  
    }

    printf("Give number a: ");
    scanf("%f", &a);
    printf("Give number b: ");
    scanf("%f", &b);

    if(sel==1){
        c=a+b;
    }
    else if(sel==2){
        if(a>b){
            c=a-b;
        }
        else{
            c=b-a;
        }
    }
    else if(sel==3){
        c=a*b;
    }
    else if(sel==4){
        if(b==0){
            printf("The process wasn't succesful.");
        }
        else{
            c=a/b;
        }
    }
    
    printf("Result: %0.4f\n", c);

system("pause"); 
return 0;   
}