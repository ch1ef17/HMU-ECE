#include <stdio.h>
#include <stdlib.h>

int main() {
    
    int a;
    float b;

    printf("Dwse tis ores: ");
    scanf("%d", &a);

    if(a<=2){
        b=4*a;
        printf("H timh einai: %f\n", b);
    }
    else if(a>2 && a<=5){
        b=3*a;
        printf("H timh einai: %f\n", b);
    }
    else if(a>5){
        b=2*a; 
        printf("H timh einai: %f\n", b);   
    }

system("pause");    
}