#include <stdio.h>
#include <stdlib.h>

int main() {
    
    int a, N;

    printf("Dwse 5 akeraious: ");

    for (N = 0; N < 5; N++) {
        scanf("%d", &a);
        if (a > 10) {
            printf("O %d einai megalyteros apo to 10.\n", a);
        } else {
            printf("o %d einai mikroteros apo to 10. \n", a);
        }
    }

system("pause");    
}