#include <stdio.h>
#define N 100

int array(int array[]){

    int a, b=0;
    printf("dwse ari8mous: ");

    while (1){

        scanf("%d", &a);
        if(a==0 || b>=N){
            break;
        }

        array[b++]=a;
    }
    return b;
}

int max(int array[], int c){

    int max_a= 0;
    for(int i=0; i<c; i++){
        if(array[i]> max_a){
            max_a = array[i];
        }
    } 

    return max_a;
}

int main() {
    
    int my_array[N];
    int b= array(my_array);
    int megisto = max(my_array, b);
    printf("megistos: %d\n", megisto);
    
}