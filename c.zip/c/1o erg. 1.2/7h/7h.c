#include <stdio.h>

void sort(int list[], int n){
    int i, k, temp;
    for(i = 0; i < n-1; i++){
        for(k = i+1; k<n; k++){
            if(list[i] > list[k]){
                temp = list[i];
                list[i] = list[k];
                list[k] = temp;
            }
        }
    }
}

int main(){
    int N;

    printf("Dwse ton ari8mo twn stroixeiwn: ");
    scanf("%d", &N);

    int list[N];
    int i;

    printf("Dwse tous ari8mous:\n");
    for (i = 0; i < N; i++) {
        scanf("%d", &list[i]);
    }
    sort(list, N);

    printf("O taksinomimenos pinakas:\n");
    for(i = 0; i < N; i++){
        printf("%d ", list[i]);
    }
    printf("\n");

    return 0;
}
