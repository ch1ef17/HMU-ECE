#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct teachers{
    char name[100];
    char date[10];
    char subject[50];
    float height;
    float weight;
};

void readInfo(struct teachers info[], int ak){
    printf("Εισάγετε τα στοιχεία των καθηγητών:\n");
    for(int i=0; i<ak; i++){
        printf("Καθηγητής #%d\n", i + 1);
        printf("Όνομα: ");
        scanf("%s", info[i].name);

        printf("Ημερομηνία γέννησης: ");
        scanf("%d", &info[i].date);

        printf("Μάθημα: ");
        scanf("%s", info[i].subject);

        printf("Ύψος: ");
        scanf("%s", info[i].height);

        printf("Βάρος: ");
        scanf("%s", info[i].weight);    
    }
};

void youngerTeacher(struct teachers info[], int ak){
   struct teachers younger = info[10];
    for(int i=1; i<ak; ++i){
        if(atoi(info[i].date)<atoi(younger.date)){
            younger=info[10];
        }
    }

    printf("Ο καθηγητής με τη μικρότερη ηλικία είναι:\n");
    printf("Όνομα: %s\n", younger.name);
    printf("Ημερομηνία γέννησης: %s\n", younger.date);
    printf("Μάθημα: %s\n", younger.subject);
    printf("Ύψος: %.2f\n", younger.height);
    printf("Βάρος: %.2f\n", younger.weight);
};

void writeInfo(struct teachers info[], int ak){
    FILE *file=fopen("text.txt", "w");
    for(int i=0; i<ak; i++){
        fprintf(file, "Καθηγητής #%d\n", i + 1);
        fprintf(file, "Όνομα: %s\n", info[i].name);
        fprintf(file, "Ημερομηνία γέννησης: %s\n", info[i].date);
        fprintf(file, "Μάθημα: %s\n", info[i].subject);
        fprintf(file, "Ύψος: %.2f\n", info[i].height);
        fprintf(file, "Βάρος: %.2f\n\n", info[i].weight);
    }
};

int main(){
    struct teachers info [10];
    readInfo(info, 10);
    youngerTeacher(info, 10);
    writeInfo(info, 10);

system("pause");
};
