#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N 100
       
struct stoixeia{
        char oe;
        int at;
        char date;
        int amka;
        char diey8insi[N];
        float mis8os;
        int ap;
    };

void saveInfoFile(struct stoixeia ypaliloy){
    FILE *file = fopen("text.txt", "a");
    fprintf(file, "%s %d %s %d %s %f %d", ypaliloy.oe, ypaliloy.at, ypaliloy.date, ypaliloy.amka, ypaliloy.diey8insi, ypaliloy.mis8os, ypaliloy.ap);
    fclose(file);
};

void loadFile(struct stoixeia ypaliloy[], int *ay){
    FILE *file = fopen("text.txt", "r");
    while (fscanf(file, "%s %d %s %d %s %f %d", ypaliloy[*ay].oe, ypaliloy[*ay].at, ypaliloy[*ay].date, ypaliloy[*ay].amka, ypaliloy[*ay].diey8insi, ypaliloy[*ay].mis8os, ypaliloy[*ay].ap) != EOF){
            (*ay)++;
    };
    fclose(file);
};

void diaforaMi8oy(struct stoixeia ypaliloy[], int ay, struct stoixeia *maxMis8osEMP, struct stoixeia *minMis8osEmp){
    float maxMis8os = ypaliloy[0].mis8os;
    float minMis8os = ypaliloy[0].mis8os;
    for(int i=1; i<ay; i++){
        if(ypaliloy[i].mis8os>maxMis8os){
          maxMis8os=ypaliloy[i].mis8os;
         *maxMis8osEMP=ypaliloy[i];
        };
        if(ypaliloy[i].mis8os<minMis8os){
            minMis8os=ypaliloy[i].mis8os;
            *minMis8osEmp=ypaliloy[i];
        };
    }
}

void neaDiey8insi(struct stoixeia ypaliloy[], int ay, int at, const char *neaDiey8insi){
    for(int i=0; i<ay; i++){
        if(ypaliloy[i].at, at ==0){
            strcpy(ypaliloy[i].diey8insi, neaDiey8insi);
        }
    }
}

int main(){
    struct stoixeia ypaliloy[N];
    int ay=0;

    printf("Εισάγετε τα στοιχεία των υπαλλήλων (Όνομα Επώνυμο ID Γέννηση AMKA Διεύθυνση Μισθός Αριθμός Παιδιών):\n");
    struct stoixeia prosorinoiYpaliloi;

    do{
        scanf("%s %d %s %d %s %f %d", prosorinoiYpaliloi.oe, prosorinoiYpaliloi.at, prosorinoiYpaliloi.date, prosorinoiYpaliloi.amka, prosorinoiYpaliloi.diey8insi, prosorinoiYpaliloi.mis8os, prosorinoiYpaliloi.ap);
        saveInfoFile(prosorinoiYpaliloi);
        ay++;
        printf("Εισάγετε τα στοιχεία του επόμενου υπαλλήλου ή πατήστε 'exit' για να τερματίσετε την εισαγωγή: ");   
    }
    while (strcmp(prosorinoiYpaliloi.oe, "exit") !=0);

    loadFile(ypaliloy, &ay);

    struct stoixeia maxMis8osYpaliloy, minMis8osYpaliloy;

    diaforaMi8oy(ypaliloy, ay, &maxMis8osYpaliloy, &minMis8osYpaliloy);

    print("\nΟ υπάλληλος με τον μέγιστο μισθό είναι: %s\n", maxMis8osYpaliloy.oe);
    print("\nΟ υπάλληλος με τον μέγιστο μισθό είναι: %s\n", minMis8osYpaliloy.oe);

system("pause");
}
