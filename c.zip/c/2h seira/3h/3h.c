#include <stdio.h>
#include <stdio.h>

int main() {
    int a, b;

    while (1) {
        printf("Dwse ari8mo kybikwn: ");
        scanf("%d", &a);

        if (a <= 0) {
            break;
        }

        if (a <= 900) {
            b = 90;
        } else if (a <= 1000) {
            b = 110;
        } else if (a <= 1400) {
            b = 135;
        } else if (a <= 2000) {
            b = 340;
        } else if (a <= 3000) {
            b = 820;
        } else {
            b = 1230;
        }

        printf("To poso poy prepei na plhrw8ei einai: %d\n", b);
    }

system("pause");
return 0;
}
