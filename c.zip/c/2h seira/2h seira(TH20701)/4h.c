#include <stdio.h>
#include <stdio.h>

int main() {
    
    int x, y;

    printf("Dwse x: ");
    scanf("%d", &x);
    printf("Dwse y: ");
    scanf("%d", &y);

    int A[x][y];

    for(int i = 0; i < x; i++){
        for(int j = 0; j < y; j++){
            printf("Dwse ari8mo gia 8esh(%d, %d): ", i + 1, j + 1);
            scanf("%d", &A[i][j]);
        }
    }

    int sum1[x];
    int Sum2[y];

    for (int i = 0; i < x; i++) {
        sum1[i] = 0;
        for (int j = 0; j < y; j++) {
            sum1[i] += A[i][j];
        }
    }

    for (int j = 0; j < y; j++) {
        Sum2[j] = 0;
        for (int i = 0; i < x; i++) {
            Sum2[j] += A[i][j];
        }
    }

    
    printf("O pinakas einai: \n");
    for (int i = 0; i < x; i++) {
        for (int j = 0; j < y; j++) {
            printf("%d\t", A[i][j]);
        }
        printf("\n");
    }

    printf("A8risma ana grammh: \n");
    for (int i = 0; i < x; i++) {
        printf("%d\t", sum1[i]);
    }

    printf("\nA8risma ana sthlh: \n");
    for (int j = 0; j < y; j++) {
        printf("%d\t", Sum2[j]);
    }

system("pause");
return 0;
}
