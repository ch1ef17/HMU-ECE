#include <stdio.h>
#include <stdio.h>

int main(){
    int a;
    int sum1 = 0;
    int sum2 = 0;

    printf("Dwse ari8mous: \n");

    while(1){
        scanf("%d", &a);

        if(a==0){
            break;
        }
        if(a % 2 ==0){
            sum1 += a;
        }else{
            sum2 += a;
        }
    }

    printf("Sum of even numbers: %d, Sum of odd numbers: %d\n", sum1, sum2);

system("pause");
return 0;
}