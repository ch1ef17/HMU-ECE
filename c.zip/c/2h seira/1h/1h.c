#include <stdio.h>
#include <stdio.h>

void a(int N){
    for(int i = 1; i <= N; i++){
        for (int j = 1; j <= i; j++){
            printf("*");
        }
        printf("\n");
    }
}

void c(int N){
    for(int i = N; i >= 1; i--){
        for(int j = 1; j <= i; j++){
            printf("*");
        }
        printf("\n");
    }
}

void d(int N){
    for(int i = N; i >= 1; i--){
        for(int j = 1; j <= N - i; j++){
            printf(" ");
        }
 
        for(int j = 1; j <= i; j++){
            printf("*");
        }
        printf("\n");
    }
}

void b(int N){
    for(int i = 1; i <= N; i++){
        for(int j = 1; j <= N - i; j++){
            printf(" ");
        }

        for(int j = 1; j <= i; j++){
            printf("*");
        }
        printf("\n");
    }
} 

void e(int N){
    for(int i = 1; i <= N; i++){
        for(int j = 1; j <= N - i; j++){
            printf(" ");
        }

        for(int j = 1; j <= i; j++){
            printf("*");
        }

        for(int j = 1; j <= i - 1; j++){
            printf("*");
        }

        printf("\n");
    }
}

int main(){

    int N;

    printf("Dwse ari8mo seirwn: ");
    scanf("%d", &N);

    printf("a) \n");
    a(N);

    printf("b) \n");
    b(N);

    printf("c) \n");
    c(N);

    printf("d) \n");
    d(N);

    printf("e) \n");
    e(N);


system("pause");
return 0;
}