#include <stdio.h>
#define SIZE 5

struct funds {
    char name[20];
    float poson; 
};

float athroisma(struct funds *persons, char ch){
   
   float sum = 0;

    for (int i = 0; i < SIZE; i++) {
        if (persons[i].name[0] == ch) {
            sum += persons[i].poson;
        }
    }

    return sum;
}

int main(){

    char ch;

    struct funds persons[SIZE];

    for (int i = 0; i < SIZE; i++) {
        printf("Dwse onoma kai poso %d: ", i + 1);
        scanf("%s %f", persons[i].name, &persons[i].poson);
    }

    printf("Dwse to proto gramma: ");
    scanf(" %c", &ch);

    printf("To a8roisma einai: %.3f\n", athroisma(persons, ch));

    return 0;
}