#include <stdio.h>

struct stype {
    int j;
    char ch[30];
    float fp;
};

void struct_swap(struct stype *s1, struct stype *s2) {
    struct stype temp = *s1;
    *s1 = *s2;
    *s2 = temp;
}

int main() {
    struct stype s1, s2;

    printf("Dwse akeraio 1: ");
    scanf("%d", &s1.j);

    printf("Dwse simbolosira 1: ");
    scanf("%s", s1.ch);

    printf("Dwse metabliti 1: ");
    scanf("%f", &s1.fp);
//----------------------------------
    printf("Dwse akeraio 2: ");
    scanf("%d", &s2.j);

    printf("Dwse simbolosira 2: ");
    scanf("%s", s2.ch);

    printf("Dwse metabliti 2: ");
    scanf("%f", &s2.fp);


    printf("before swap: \n");
    printf("S1: %d %s %0.3f\n", s1.j, s1.ch, s1.fp);
    printf("S2: %d %s %0.3f\n", s2.j, s2.ch, s2.fp);


    struct_swap(&s1, &s2);

    printf("after swap: \n");
    printf("S1: %d %s %0.3f\n", s1.j, s1.ch, s1.fp);
    printf("S2: %d %s %0.3f\n", s2.j, s2.ch, s2.fp);

    return 0;
}
